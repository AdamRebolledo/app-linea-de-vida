/*
|--------------------------------------------------------------------------
| Custom Javascript code
|--------------------------------------------------------------------------
|
| Now that you configured your website, you can write additional Javascript
| code inside the following function. You might want to add more plugins and
| initialize them in this file.
|
*/

$(function() {
    $(".slick-slider").slick({
        variableWidth: true,
        slidesToShow: 2,
        slidesToScroll: 2
    });

});