import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-atencion',
  templateUrl: './atencion.component.html',
  styleUrls: ['./atencion.component.scss']
})
export class AtencionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
