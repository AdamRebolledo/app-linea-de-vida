import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preguntasfrecuentes',
  templateUrl: './preguntasfrecuentes.component.html',
  styleUrls: ['./preguntasfrecuentes.component.scss']
})
export class PreguntasfrecuentesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
